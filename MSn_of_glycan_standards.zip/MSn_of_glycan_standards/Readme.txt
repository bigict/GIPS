
README

---------------------------------------------------

1. Files in this directory

Each sub-directory containing mass spectra of a glycan.

2. Format of mass spectrum files
   
All mass spectrum files are in mzXML format, and filename represents mass of the precursor ions of the spectrum, e.g., 

1579.mzXML: MS2 spectrum file, precursor mass: 1579
1579_1302.mzXML: MS3 spectrum file, precursor mass: 1302        
1579_1302_1084.mzXML: MS4 spectrum file, precursor mass: 1084 
1579_1302_1084_866.mzXML: MS5 spectrum file, precursor mass: 866 

3. Peak selection paths 

A2: MS2(2972) 
Hybrid-Octa: MS2(1824)->MS3(1102)
Man-5D1: MS2(1579)->MS3(1084)
Man-6: MS2(1783)->MS3(1084)->MS4(385)Null mass spectrum->MS4(667)
Man-7D3: MS2(1987)->MS3(1492)->MS4(825)
Man-7D1: MS2(1987)->MS3(1084)
LNFP1: MS2(1100)
LNFP2: MS2(1100)->MS3(864)
