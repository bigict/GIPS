1783.mzXML: MS2 spectrum file, mass: 1783
1783_1084.mzXML: MS3 spectrum file, mass: 1084
1783_1084_667.mzXML: MS4 spectrum file, mass 667